Hello Developer,

Please keep in mind that this project is currently active development.

I'm recording and editing the upcoming videos for this section.

When already is done, then I will upload the files of the finished project here and delete this message.

It will be available to download as soon as possible but you can always start the project and follow me without this file.

Thank you for your understanding.

Until then, happy coding!

Robert
